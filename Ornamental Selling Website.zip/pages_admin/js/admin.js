const them = document.getElementById("them");
const ctn_show_them = document.getElementById("container-show-them");


them.addEventListener('mouseover', () => {
    ctn_show_them.style.display = "block";


});
ctn_show_them.addEventListener('mouseover', () => {
    ctn_show_them.style.display = "block";


});
ctn_show_them.addEventListener('mouseout', () => {
    ctn_show_them.style.display = "none";


});
