    <?php 
        include("bonsai.php")
    ?>
    <!--  -->
    <?php 
        include("pots.php")
    ?>
    <!--  -->
    <?php 
        include("fertilizer.php")
    ?>
