
<div class="container-search">
    <div class="box-search">
        <form class="form-search" action="" method="post">
            <input type="text" class="input-search" name="search" placeholder="Sản phẩm cần tìm">
            <input type="submit" class="submit-search" name="sbm-search" value="Search">
            <input type="submit" class="submit-delete" name="sbm-delete" value="Delete">
        </form>
    </div>

    <div class="cart">
        <a href="http://localhost:8080/Ornamental%20Selling%20Website/pages_guests/cart.php?action=add"><i class="fa-solid fa-cart-shopping"></i></a>
    </div>
</div>
