<div class="container-menu">
    <ul>
        <!-- <li><a   class="active" href="../index.php?pages_guests=products">Home</a></li> -->
        <li><a   class="active" href="http://localhost:8080/Ornamental%20Selling%20Website/index.php?pages_guests=products">Home</a></li>

        <!-- <li><a   href="../index.php?pages_guests=bonsai">Bonsai<i class="fa-solid fa-caret-up fa-rotate-180"></i></a></li> -->
        <li><a   href="http://localhost:8080/Ornamental%20Selling%20Website/index.php?pages_guests=bonsai">Bonsai<i class="fa-solid fa-caret-up fa-rotate-180"></i></a></li>

        <!-- <li><a   href="../index.php?pages_guests=pots">Chậu <i class="fa-solid fa-caret-up fa-rotate-180"></i></a></li> -->
        <li><a   href="http://localhost:8080/Ornamental%20Selling%20Website/index.php?pages_guests=pots">Chậu <i class="fa-solid fa-caret-up fa-rotate-180"></i></a></li>

        <li><a   href="../index.php?pages_guests=fertilizer">Phân bón</a></li>
 
    </ul>
</div>